enum class MPISortOption
{
	BITONIC,
	ODD_EVEN,
	BUCKET,
	DIRECT,
	RANK,
	SHELL,
	Count
};